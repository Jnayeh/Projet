import { PersonalisedPipe } from './personalised.pipe';

describe('PersonalisedPipe', () => {
  it('create an instance', () => {
    const pipe = new PersonalisedPipe();
    expect(pipe).toBeTruthy();
  });
});
