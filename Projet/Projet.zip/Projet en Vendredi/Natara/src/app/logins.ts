import { Router } from '@angular/router';
export class Logins {
admn:boolean=false;

    constructor(private router:Router){}
   
}
